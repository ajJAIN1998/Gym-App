package com.example.gymscape.ui;

public enum UsedEnums {
    CATEGORY,
    EXERCISE,
    PICK_IMAGE,
    WORKOUT
}
